import sys

def fac(n) : 
    if n == 1 : 
        return 1
    return n * fac(n-1)

if __name__ == '__main__' : 
    start = int(sys.argv[1])
    end = int(sys.argv[2])
    Sum = 0
    for i in range(start, end + 1) : 
        Sum += fac(i)

    print(Sum)

import math
import sys

# A function to print all prime factors of  
# a given number n 
def primeFactors(num): 
    factors = set()
      
    # Add the number of two's that divide n 
    while num % 2 == 0: 
        factors.add(2)
        num = num / 2
          
    # n must be odd at this point 
    # so a skip of 2 ( i = i + 2) can be used 
    for i in range(3, int(math.sqrt(num))+1, 2): 
          
        # while i divides n , add i and divide n 
        while num % i== 0: 
            factors.add(int(i))
            num = num / i 
              
    # Condition if n is a prime 
    # number greater than 2 
    if num > 2: 
        factors.add(int(num))
    return factors

if __name__ == '__main__' : 
    prime_num = int(sys.argv[1])
    print(primeFactors(prime_num))
